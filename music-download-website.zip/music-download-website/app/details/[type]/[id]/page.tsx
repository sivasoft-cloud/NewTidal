import { getDetails, getCoverImage } from '../../../lib/api'
import Image from 'next/image'

export default async function DetailsPage({ params, searchParams }: { params: { type: string, id: string }, searchParams: URLSearchParams }) {
  const { type, id } = params
  const details = await getDetails(id, type, searchParams.quality || 'HI_RES')
  const coverUrl = await getCoverImage(id)

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">{details.title || details.name}</h1>
      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-1/3">
          <Image src={coverUrl} alt={details.title || details.name} width={300} height={300} className="rounded shadow" />
        </div>
        <div className="w-full md:w-2/3">
          {type === 's' && (
            <>
              <p className="text-xl mb-2">Artist: {details.artist}</p>
              <p className="text-xl mb-2">Album: {details.album}</p>
              <p className="text-xl mb-2">Duration: {details.duration}</p>
              <select
                onChange={(e) => {
                  const newQuality = e.target.value;
                  window.location.href = `?quality=${newQuality}`;
                }}
                className="p-2 border border-gray-300 rounded mb-4"
              >
                <option value="HI_RES_LOSSLESS">Hi-Res Lossless</option>
                <option value="HI_RES">Hi-Res</option>
                <option value="LOSSLESS">Lossless</option>
                <option value="HIGH">High</option>
                <option value="LOW">Low</option>
              </select>
              <a
                href={details.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block mt-4 px-6 py-3 bg-green-500 text-white rounded hover:bg-green-600"
              >
                Download Track
              </a>
            </>
          )}
          {type === 'a' && (
            <p className="text-xl mb-2">Popular Tracks: {details.popularTracks?.join(', ')}</p>
          )}
          {type === 'al' && (
            <>
              <p className="text-xl mb-2">Artist: {details.artist}</p>
              <p className="text-xl mb-2">Release Date: {details.releaseDate}</p>
              <p className="text-xl mb-2">Number of Tracks: {details.numberOfTracks}</p>
            </>
          )}
          {type === 'v' && (
            <>
              <p className="text-xl mb-2">Artist: {details.artist}</p>
              <p className="text-xl mb-2">Duration: {details.duration}</p>
              <a
                href={details.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block mt-4 px-6 py-3 bg-green-500 text-white rounded hover:bg-green-600"
              >
                Watch Video
              </a>
            </>
          )}
          {type === 'p' && (
            <>
              <p className="text-xl mb-2">Creator: {details.creator}</p>
              <p className="text-xl mb-2">Number of Tracks: {details.numberOfTracks}</p>
              <p className="text-xl mb-2">Duration: {details.duration}</p>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

