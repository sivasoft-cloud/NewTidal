import SearchForm from './components/SearchForm'
import SearchResults from './components/SearchResults'
import { searchTidal } from './lib/api'

export default async function Home({
  searchParams
}: {
  searchParams: { q?: string, type?: string, quality?: string }
}) {
  const query = searchParams.q
  const type = searchParams.type || 's'
  const quality = searchParams.quality || 'HI_RES'
  const results = query ? await searchTidal(query, type) : null

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Tidal Music Search</h1>
      <SearchForm initialQuery={query} initialType={type} initialQuality={quality} />
      {results && <SearchResults results={results} />}
      {query && !results && <p className="mt-4 text-center text-red-500">No results found. Please try a different search.</p>}
    </div>
  )
}

