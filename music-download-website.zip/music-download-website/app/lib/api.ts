const API_BASE = "https://tidal.401658.xyz";

export async function searchTidal(query: string, type: string = 's') {
  const response = await fetch(`${API_BASE}/search/?${type}=${encodeURIComponent(query)}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const data = await response.json();
  return data.items.map((item: any) => ({
    ...item,
    OriginalTrackUrl: item.OriginalTrackUrl || null
  })) || [];
}

export async function getTrackDetails(trackId: string, quality: string = 'HI_RES') {
  const response = await fetch(`${API_BASE}/track/?id=${trackId}&quality=${quality}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return await response.json();
}

export async function getCoverImage(id: string, query?: string) {
  const params = id ? `id=${id}` : `q=${encodeURIComponent(query || '')}`;
  const response = await fetch(`${API_BASE}/cover/?${params}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const data = await response.json();
  return data.url;
}

export async function searchSong(query: string, quality: string = 'HI_RES') {
  const response = await fetch(`${API_BASE}/song/?q=${encodeURIComponent(query)}&quality=${quality}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return await response.json();
}

export async function getAlbumDetails(albumId: string) {
  const response = await fetch(`${API_BASE}/album/?id=${albumId}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return await response.json();
}

