import Link from 'next/link'

interface TrackResult {
  id: number;
  title: string;
  duration: number;
  artist: {
    name: string;
  };
  album: {
    title: string;
  };
  audioQuality: string;
  explicit: boolean;
  url: string;
  OriginalTrackUrl?: string;
}

export default function SearchResults({ results }: { results: TrackResult[] }) {
  if (!results || results.length === 0) {
    return <p className="mt-4 text-center">No results found.</p>
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Search Results</h2>
      <ul className="space-y-4">
        {results.map((item) => (
          <li key={item.id} className="border p-4 rounded shadow">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold">{item.title}</h3>
                <p>Artist: {item.artist.name}</p>
                <p>Album: {item.album.title}</p>
                <p>Duration: {Math.floor(item.duration / 60)}:{(item.duration % 60).toString().padStart(2, '0')}</p>
                <p>Quality: {item.audioQuality}</p>
                {item.explicit && <p className="text-red-500">Explicit</p>}
              </div>
              <div className="flex flex-col space-y-2">
                <Link href={`/track/${item.id}`} className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-center">
                  View Details
                </Link>
                <a href={item.url} target="_blank" rel="noopener noreferrer" className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 text-center">
                  Open in Tidal
                </a>
                {item.OriginalTrackUrl && (
                  <a href={item.OriginalTrackUrl} target="_blank" rel="noopener noreferrer" className="px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 text-center">
                    Original Track
                  </a>
                )}
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

