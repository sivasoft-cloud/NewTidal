'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function SearchForm({ initialQuery = '', initialType = 's', initialQuality = 'HI_RES' }) {
  const [query, setQuery] = useState(initialQuery)
  const [type, setType] = useState(initialType)
  const [quality, setQuality] = useState(initialQuality)
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    router.push(`/?q=${encodeURIComponent(query)}&type=${type}&quality=${quality}`)
  }

  return (
    <form onSubmit={handleSubmit} className="mb-6">
      <div className="flex flex-col md:flex-row gap-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your search query"
          className="flex-grow p-2 border border-gray-300 rounded"
          required
        />
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="p-2 border border-gray-300 rounded"
        >
          <option value="s">Song</option>
          <option value="a">Artist</option>
          <option value="al">Album</option>
          <option value="v">Video</option>
          <option value="p">Playlist</option>
        </select>
        <select
          value={quality}
          onChange={(e) => setQuality(e.target.value)}
          className="p-2 border border-gray-300 rounded"
        >
          <option value="HI_RES_LOSSLESS">Hi-Res Lossless</option>
          <option value="HI_RES">Hi-Res</option>
          <option value="LOSSLESS">Lossless</option>
          <option value="HIGH">High</option>
          <option value="LOW">Low</option>
        </select>
        <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
          Search
        </button>
      </div>
    </form>
  )
}

